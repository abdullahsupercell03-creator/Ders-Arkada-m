package com.example.dersarkadasim

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.CountDownTimer
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private val purple = Color.rgb(103, 80, 164)
    private val ink = Color.rgb(35, 32, 43)
    private val bg = Color.rgb(247, 245, 250)
    private lateinit var content: LinearLayout
    private lateinit var prefs: android.content.SharedPreferences
    private var timer: CountDownTimer? = null
    private var seconds = 25 * 60
    private var running = false
    private var tasks = mutableListOf<String>()
    private var completed = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("study", Context.MODE_PRIVATE)
        completed = prefs.getInt("completed", 0)
        tasks = prefs.getStringSet("tasks", emptySet())!!.toMutableList()
        showHome()
    }

    private fun base(title: String) {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(20, 18, 20, 12)
        }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        outer.addView(label(title, 27f, true, ink).apply { setPadding(0, 8, 0, 18) })
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 4)
        }
        listOf("Ana sayfa", "Zamanlayıcı", "Görevler", "Test").forEach { name ->
            val b = Button(this).apply {
                text = name
                textSize = 11f
                isAllCaps = false
                setTextColor(purple)
                setOnClickListener {
                    when(name) {
                        "Ana sayfa" -> showHome()
                        "Zamanlayıcı" -> showTimer()
                        "Görevler" -> showTasks()
                        else -> showQuiz()
                    }
                }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        outer.addView(nav)
        setContentView(outer)
    }

    private fun label(text: String, size: Float = 16f, bold: Boolean = false, color: Int = ink) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun card(title: String, body: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(Color.WHITE)
        }
        box.addView(label(title, 17f, true))
        box.addView(label(body, 14f).apply { setPadding(0, 7, 0, 0) })
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 12
        content.addView(box, lp)
    }

    private fun action(text: String, onClick: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(purple)
            setOnClickListener { onClick() }
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 10
        content.addView(b, lp)
    }

    private fun showHome() {
        base("Ders Arkadaşım 📚")
        val xp = completed * 20
        card("Bugünkü çalışma", "Tamamlanan görev: $completed\nToplam puanın: $xp XP\nSeviyen: ${1 + xp / 100}")
        card("Hızlı başlangıç", "25 dakika odaklan, ardından kısa bir mola ver. Küçük adımlar büyük ilerleme sağlar.")
        action("⏱ Çalışmaya başla") { showTimer() }
        action("＋ Yeni görev ekle") { addTask() }
        action("🧠 Mini teste gir") { showQuiz() }
        card("Tasarım seçenekleri", "Modern görünüm • Oyunlaştırma • Sade menüler\nHepsi tek uygulamada!")
    }

    private fun showTimer() {
        base("Odaklanma sayacı")
        val time = label(String.format("%02d:%02d", seconds / 60, seconds % 60), 48f, true, purple)
        time.gravity = Gravity.CENTER
        content.addView(time, LinearLayout.LayoutParams(-1, 150))
        card("Pomodoro", "25 dakika çalışma + 5 dakika mola")
        action(if (running) "Duraklat" else "Başlat") {
            if (!running) {
                running = true
                timer = object : CountDownTimer(seconds * 1000L, 1000) {
                    override fun onTick(ms: Long) {
                        seconds = (ms / 1000).toInt()
                        time.text = String.format("%02d:%02d", seconds / 60, seconds % 60)
                    }
                    override fun onFinish() {
                        running = false; seconds = 0
                        time.text = "00:00"
                        completed++; prefs.edit().putInt("completed", completed).apply()
                        AlertDialog.Builder(this@MainActivity).setMessage("Harika! Bir odak oturumu tamamladın. +20 XP").setPositiveButton("Tamam", null).show()
                    }
                }.start()
            } else {
                timer?.cancel(); running = false
            }
        }
        action("Sıfırla") { timer?.cancel(); running = false; seconds = 1500; showTimer() }
        action("5 dakikalık mola") { timer?.cancel(); running = false; seconds = 300; showTimer() }
    }

    private fun showTasks() {
        base("Görevlerim")
        action("＋ Görev ekle") { addTask() }
        if (tasks.isEmpty()) card("Henüz görev yok", "Derslerini ve ödevlerini buraya ekleyebilirsin.")
        tasks.toList().forEach { task ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(label("• $task", 15f), LinearLayout.LayoutParams(0, -2, 1f))
            val done = Button(this).apply {
                text = "✓"
                setOnClickListener {
                    tasks.remove(task); completed++
                    prefs.edit().putStringSet("tasks", tasks.toSet()).putInt("completed", completed).apply()
                    showTasks()
                }
            }
            row.addView(done)
            content.addView(row)
        }
    }

    private fun addTask() {
        val input = EditText(this).apply { hint = "Örn. Matematik testini çöz" }
        AlertDialog.Builder(this).setTitle("Yeni görev").setView(input)
            .setPositiveButton("Ekle") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isNotEmpty()) {
                    tasks.add(value); prefs.edit().putStringSet("tasks", tasks.toSet()).apply()
                    showTasks()
                }
            }.setNegativeButton("Vazgeç", null).show()
    }

    private fun showQuiz() {
        base("Mini test 🧠")
        card("Soru 1 / 3", "Ağırlık hangi tür büyüklüktür?")
        listOf("Skaler", "Vektörel", "Temel").forEach { answer ->
            action(answer) {
                val correct = answer == "Vektörel"
                if (correct) { completed++; prefs.edit().putInt("completed", completed).apply() }
                AlertDialog.Builder(this).setMessage(if (correct) "Doğru! +20 XP 🎉" else "Tekrar dene. Ağırlık vektörel bir büyüklüktür.")
                    .setPositiveButton("Tamam", null).show()
            }
        }
        card("İpucu", "Ağırlığın hem büyüklüğü hem yönü vardır.")
    }
}